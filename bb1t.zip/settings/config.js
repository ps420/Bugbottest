const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "2348084718594"
global.nama = "𝔸𝕄𝔹𝔸𝕊𝕊𝔸𝔻𝕆ℝ"
global.ch = 'https://whatsapp.com/channel/0029Vb0vJyK7YSd47MHot92O'
global.status = true
//====== [ THEME URL & URL ] ========//
global.thumb = "https://files.catbox.moe/d305d2.jpg" // Buffer Image
global.thumbnail = 'https://files.catbox.moe/d305d2.jpg' 
global.Url = '-'

global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

global.packname = '𝔸𝕄𝔹𝔸𝕊𝕊𝔸𝔻𝕆ℝ'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
